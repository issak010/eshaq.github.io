# Ishaq Portfolio

A responsive, single-page portfolio website.

## Before publishing
Open `index.html` and replace:
- `YOUR_EMAIL@example.com`
- `YOUR_GITHUB_USERNAME`
- `YOUR_LINKEDIN_USERNAME`

Also check the name and project descriptions, and remove anything that does not accurately describe your work.

## Publish free with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new public repository named `YOUR_GITHUB_USERNAME.github.io`.
3. Upload `index.html` to the repository's main/root folder.
4. Open **Settings → Pages** and make sure deployment from the `main` branch and `/ (root)` is selected if prompted.
5. Wait for deployment. Your website address will be `https://YOUR_GITHUB_USERNAME.github.io/`.
